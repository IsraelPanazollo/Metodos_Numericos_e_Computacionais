# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 21:47:59 2017

@author: israe
"""

x = 1.

while (x + 1) > 1:
    x = x/2
    print x
    
    
import math
w=-0.2
k = 1
x = 0.
erro = 1.
 
 
while erro > 0.0001:
    x = x + (((-1)**(k-1))*(w**k))/k
    erro = math.fabs((x - math.log(0.8)))
    print k, "tentativa = ", x, "erro = ", erro
    k = k+1